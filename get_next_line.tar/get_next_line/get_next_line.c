#include "get_next_line.h"

char	*ft_strjoin(char const *s1, char const *s2)
{
	size_t	len;
	char	*ret;

	len = strlen(s1) + strlen(s2) + 1;
	ret = malloc(len);
	if (!ret)
		return (NULL);
	strlcpy(ret, s1, len);
	strlcat(ret, s2, len);
	return (ret);
}

char	*get_next_line(int fd)
{
	static 	char *bank = NULL;
	ssize_t	bytes_read;
	char	buf[BUFFER_SIZE];
	char	*new_line;
	char	*tmp;
	char	*ret;

	if (!bank)
	{
		bytes_read = read(fd, buf, BUFFER_SIZE);
		if (bytes_read)
		{
			bank = malloc(bytes_read + 1);
			strlcpy(bank, buf, bytes_read + 1);
		}
	}
	else
		bytes_read = strlen(bank);
	while (bytes_read)
	{
		new_line = strchr(bank, '\n');
		if (new_line)
		{
			ret = strndup(bank, new_line - bank);
			tmp = strdup(new_line + 1);
			free(bank);
			bank = tmp;
			return ret;
		}
		bytes_read = read(fd, buf, BUFFER_SIZE - 1); 
		buf[bytes_read] = '\0';
		tmp = ft_strjoin(bank, buf);
		free(bank);
		bank = tmp;
	}
	if (bank)
	{
		ret = strdup(bank);
		free(bank);
		bank = NULL;
		return ret;
	}
	return NULL;
}
