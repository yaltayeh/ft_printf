#include "get_next_line.h"
#include <stdio.h>
#include <fcntl.h>

int main()
{
    int fd;

    fd = open("test.txt", O_RDONLY);
    if (fd == -1)
    {
        printf("Can't open file\n");
        return 1;
    }
    char *str;
    while ((str = get_next_line(fd)))
        printf("%s\n", str);
    
    close(fd);
}